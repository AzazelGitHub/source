package com.cg.emp.ui;

import com.cg.emp.bean.EmployeeBean;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;

import java.util.List;

public class Application {



    public static void main(String args[]){

        EmployeeService service = new EmployeeServiceImpl();
        List<EmployeeBean> list = service.getAllEmp();

        for (EmployeeBean emp : list
             ) {
            System.out.println(emp);
        }

    }

}
