package com.cg.emp.dao;

public interface IQueryMapper {

    public static final String GET_ALL_EMPLOYEES = "SELECT * from employees";

}
