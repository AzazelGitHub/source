package com.cg.emp.dao;

import com.cg.emp.bean.EmployeeBean;

import java.util.List;

public interface EmployeeDao {

    public List<EmployeeBean> getAllEmp();

}
