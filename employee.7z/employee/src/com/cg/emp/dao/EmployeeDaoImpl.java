package com.cg.emp.dao;

import com.cg.emp.bean.EmployeeBean;
import com.cg.emp.util.DbConnection;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao {

    Connection conn = null;
    ResultSet rs = null;

    @Override
    public List<EmployeeBean> getAllEmp() {

            List<EmployeeBean> empList = new ArrayList<>();
            int donorCount = 0;
            try{
                conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","12345");
                PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.GET_ALL_EMPLOYEES);
                 rs = preparedStatement.executeQuery();

                 while(rs.next()){
                     EmployeeBean bean = new EmployeeBean();
                     System.out.println("HI");
                     bean.setEmpId(rs.getInt(1));
                     bean.setEmpName(rs.getString(2));
                     bean.setEmpBalance(rs.getLong(3));
                     empList.add(bean);
                     donorCount++;
                 }

            }catch(SQLException e){
                e.printStackTrace();
            }
            System.out.println(donorCount);
            if(donorCount==0) {
                return null;
            }
            else {
                return empList;
            }
    }

}
