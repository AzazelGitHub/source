package com.cg.emp.util;
import java.sql.*;

public class DbConnection {
    static Connection conn = null;

    public static Connection getDatabaseConnection() throws SQLException{

        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","12345");

        return conn;

    }


}
