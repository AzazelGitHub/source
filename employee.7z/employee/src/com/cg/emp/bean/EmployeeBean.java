package com.cg.emp.bean;

import lombok.Data;

@Data
public class EmployeeBean {

    private int empId;
    private String empName;
    private long empBalance;

}
