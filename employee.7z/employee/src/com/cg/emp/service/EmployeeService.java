package com.cg.emp.service;

import com.cg.emp.bean.EmployeeBean;

import java.util.List;

public interface EmployeeService {

    public List<EmployeeBean> getAllEmp();

}
