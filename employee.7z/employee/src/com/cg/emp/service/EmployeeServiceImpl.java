package com.cg.emp.service;
import com.cg.emp.bean.EmployeeBean;
import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dao.EmployeeDaoImpl;

import java.util.ArrayList;
import java.util.List;

public class EmployeeServiceImpl implements EmployeeService{

    EmployeeDao dao = new EmployeeDaoImpl();

    @Override
    public List<EmployeeBean> getAllEmp() {
        List<EmployeeBean> empList = new ArrayList<>();
        empList=dao.getAllEmp();

        return empList;
    }
}
